-- ALHAZ RAJBARI LIVE: run once in Supabase SQL Editor
-- Uses authenticated owner control + anonymous authenticated OBS viewer.
create table if not exists public.broadcast_rooms (
  topic text primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.broadcast_rooms enable row level security;
drop policy if exists "room owner can read own room" on public.broadcast_rooms;
create policy "room owner can read own room" on public.broadcast_rooms
for select to authenticated using (owner_id = auth.uid() or topic = (select realtime.topic()));
drop policy if exists "user can create own room" on public.broadcast_rooms;
create policy "user can create own room" on public.broadcast_rooms
for insert to authenticated with check (owner_id = auth.uid());

create table if not exists public.broadcast_state (
  topic text primary key references public.broadcast_rooms(topic) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.broadcast_state enable row level security;
drop policy if exists "owner and matching overlay can read state" on public.broadcast_state;
create policy "owner and matching overlay can read state" on public.broadcast_state
for select to authenticated using (
  owner_id = auth.uid() or topic = (select realtime.topic())
);
drop policy if exists "owner can insert state" on public.broadcast_state;
create policy "owner can insert state" on public.broadcast_state
for insert to authenticated with check (owner_id = auth.uid() and exists (
  select 1 from public.broadcast_rooms r where r.topic = broadcast_state.topic and r.owner_id = auth.uid()
));
drop policy if exists "owner can update state" on public.broadcast_state;
create policy "owner can update state" on public.broadcast_state
for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Realtime private-channel authorization.
drop policy if exists "room members can receive graphics broadcast" on realtime.messages;
create policy "room members can receive graphics broadcast" on realtime.messages
for select to authenticated using (
  extension = 'broadcast' and exists (
    select 1 from public.broadcast_rooms r where r.topic = (select realtime.topic())
  )
);
drop policy if exists "only room owner can send graphics broadcast" on realtime.messages;
create policy "only room owner can send graphics broadcast" on realtime.messages
for insert to authenticated with check (
  extension = 'broadcast' and exists (
    select 1 from public.broadcast_rooms r
    where r.topic = (select realtime.topic()) and r.owner_id = auth.uid()
  )
);

-- Public-read logo assets; only authenticated users may upload into their own folder.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('broadcast-assets','broadcast-assets',true,5242880,array['image/webp','image/png','image/jpeg'])
on conflict (id) do update set public = true;
drop policy if exists "user can upload own broadcast assets" on storage.objects;
create policy "user can upload own broadcast assets" on storage.objects
for insert to authenticated with check (
  bucket_id = 'broadcast-assets' and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "public can view broadcast assets" on storage.objects;
create policy "public can view broadcast assets" on storage.objects
for select to public using (bucket_id = 'broadcast-assets');
